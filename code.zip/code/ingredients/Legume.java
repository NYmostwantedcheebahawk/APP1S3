package ingredients;

public class Legume extends Ingredient{
    public Legume(String s) {
        setStateIngredient(s);
        setTypeIngredient(TypeIngredient.LEGUME);
    }
}
