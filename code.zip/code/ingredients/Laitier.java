package ingredients;

public class Laitier extends Ingredient {
    public Laitier(String s) {
        setStateIngredient(s);
        setTypeIngredient(TypeIngredient.LAITIER);
    }
}